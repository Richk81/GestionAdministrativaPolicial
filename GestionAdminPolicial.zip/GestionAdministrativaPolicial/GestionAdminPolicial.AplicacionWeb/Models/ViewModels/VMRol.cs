﻿using GestionAdminPolicial.Entity;

namespace GestionAdminPolicial.AplicacionWeb.Models.ViewModels
{
    public class VMRol
    {
        public int IdRol { get; set; }

        public string? Descripcion { get; set; }

    }
}
