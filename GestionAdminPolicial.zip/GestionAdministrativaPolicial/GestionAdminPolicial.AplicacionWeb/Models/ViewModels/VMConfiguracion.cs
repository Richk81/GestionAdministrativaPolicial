﻿namespace GestionAdminPolicial.AplicacionWeb.Models.ViewModels
{
    public class VMConfiguracion
    {
        public string? Recurso { get; set; }

        public string? Propiedad { get; set; }

        public string? Valor { get; set; }
    }
}
