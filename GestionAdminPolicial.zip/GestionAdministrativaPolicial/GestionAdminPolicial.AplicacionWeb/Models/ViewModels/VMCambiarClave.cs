﻿namespace GestionAdminPolicial.AplicacionWeb.Models.ViewModels
{
    public class VMCambiarClave
    {
        public string? ClaveActual { get; set; }
        public string? NuevaClave { get; set; }

    }
}
